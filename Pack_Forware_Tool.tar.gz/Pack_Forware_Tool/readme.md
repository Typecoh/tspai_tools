#使用说明
./unpack.sh 命令进行解压，生成一个output文件夹，在这个文件夹中有两个文件
分别是Image 镜像文件以及packge-file文件
将自己创建的ubuntu镜像rootfs替换Image中的rootfs镜像
使用./pack.sh 生成新的update.img文件
