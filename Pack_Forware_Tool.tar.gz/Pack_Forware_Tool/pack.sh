#!/bin/bash
pause()
{
echo "Press any key to quit:"
read -n1 -s key
exit 1
}

if [ ! -d "output" ]; then 
	echo "目录output不存在"
	pause
fi

if [ -f "update.img" ]; then
	rm update.img
#	echo "update.img 存在"
	#	pause
fi

# 将output 里面的 Image 和 package-file 复制到 当前目录下
cp output/* ./ -rf

# 添加可执行权限
#chmod 777 Image
#chmod 777 package-file

# 执行./mkupdate.sh 脚本
./mkupdate.sh

# 执行完脚本之后 ，删除 Image 和 package-file 文件
rm Image package-file -rf
